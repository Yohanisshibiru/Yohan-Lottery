YOHAN LOTTERY 2.0 — FIREBASE SETUP

1) ADMIN EMAIL
Choose an email address you control. Replace REPLACE_WITH_YOUR_ADMIN_EMAIL in BOTH index.html (ADMIN_EMAIL) and firestore.rules with exactly the same email.

2) CREATE ADMIN USER
Firebase Console > Build > Authentication > Users > Add user.
Create a user with that email and a strong password. Keep the password private.

3) PUBLISH DATABASE RULES
Firebase Console > Build > Firestore Database > Rules.
Replace the rules with firestore.rules after replacing the admin email. Click Publish.
These rules let anyone submit a registration, but only the configured admin can read participant records. Public users can read winner announcements.

4) DEPLOY WEBSITE
The website uses JavaScript modules, so test it through a web server, not by opening index.html as file://.
For Firebase Hosting, on a computer with Node.js:
  npm install -g firebase-tools
  firebase login
  firebase init hosting
Select existing project yohan-lottery-5cde1 and set the public directory to the folder containing index.html.
Then run:
  firebase deploy --only hosting

5) ANDROID
Once hosted, the responsive website can be opened on Android. A later step can package it as an installable PWA or Android app.

SECURITY AND FAIRNESS
The Firebase web API key is browser configuration, not a server secret. Do not expose service-account keys or passwords.
This prototype chooses the winner in the admin browser; it is not server-audited and should only be used for informal free draws. Do not use it for paid, regulated, or high-value lotteries. For audited draws, implement server-side winner selection with appropriate access controls and logs.
